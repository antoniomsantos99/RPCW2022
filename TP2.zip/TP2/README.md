# TPC 2

Status: In Progress

## Ex 1

- [x]  Ler ficheiro [json](https://epl.di.uminho.pt/~jcr/AULAS/ATP2021/datasets/cinemaATP.json)
- [x]  Gerar pagina html para cada registo

## Ex 2

- [x]  Criar servidor para servir as paginas (formato: localhost:PORTA/filmes/f{indice} )

## Ex 3

- [x]  Criar servidor para servir as paginas (formato: localhost:PORTA/filmes/ que apresenta lista de filmes como hiperligação)

## Ex 4 (opcional)

- [x]  Tambem servir paginas de atores que apresenta nome e lista de filmes em que participa
- [x]  Tambem servir paginas de categorias que apresenta nome e lista de filmes em que incluidos